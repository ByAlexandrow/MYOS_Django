from pytest_django.asserts import assertRedirects

from django.urls import reverse

from texts.models import Texts
