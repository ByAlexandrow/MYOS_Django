import pytest

from django.test.client import Client

from texts.models import Texts
